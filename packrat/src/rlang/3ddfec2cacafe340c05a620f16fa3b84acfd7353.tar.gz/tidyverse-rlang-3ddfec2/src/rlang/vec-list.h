#ifndef RLANG_VECTOR_LIST_H
#define RLANG_VECTOR_LIST_H


void mut_list_at(SEXP list, r_size_t i, SEXP elt);


#endif
