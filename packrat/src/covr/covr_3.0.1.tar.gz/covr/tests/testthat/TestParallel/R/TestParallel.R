#' an example function
#'
#' @export
test1 <- function(x, y){
  x + y
}

#' @export
test2 <- function(x, y){
  x * y
}

#' @export
test3 <- function(x, y){
  x - y
}